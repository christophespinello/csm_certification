#!/usr/bin/python3
# -*- coding: utf8 -*-

import time
from tt1pv2_serial import TT1PV2_Serial, TT1PV2_CONNECTION_TYPE_UART, \
    TT1PV2_CONNECTION_TYPE_BLE
import json
from test_loop import test_loop
from bcolors import bcolors

#SOFTWARE_VERSION = '1.0.21'
with open ("VERSION", "r") as myfile:
    SOFTWARE_VERSION=myfile.readline()

JSON_FILENAME = "./test_macros.json"

DEBUG = 0

class ConsoleTT1PV2(object):

    def __init__(self) :
        
        self.tt1pv2_serial = TT1PV2_Serial()
        self.ptr_sequencer = 'SEQ_INIT'
        self.running = True
        self.test_loop = test_loop(interface=self.tt1pv2_serial)
        self.sequencer(self.ptr_sequencer)
            
    def seq_init(self):
        print(bcolors.HEADER)
        print("=========================================")
        print("         console CSM TT1PV2")
        print("                                  v" + SOFTWARE_VERSION)
        print("=========================================")
        print(bcolors.ENDC)
        if (DEBUG == 1) :
            self.ptr_sequencer = 'SEQ_LOOP'
        else :
            self.ptr_sequencer = 'SEQ_CONFIGURE_CONNECTION'

    def seq_configure_connection(self):
        self.tt1pv2_serial.configure()
        self.ptr_sequencer = 'SEQ_CONNECT'
        
    def seq_connect(self):
        self.tt1pv2_serial.connect()
        self.ptr_sequencer = 'SEQ_CONFIGURE_PRODUCT'

    def seq_configure_product(self):
        err = self.tt1pv2_serial.send_frame("ble_test_onoff 10", timeout=1)
        if (err['str'] == "Disable TimeOut Appairage !!!") :
            print("The product is alive")
            self.ptr_sequencer = 'SEQ_LOOP'
        else :
            print("Problem in activating product")
            quit()
            
    def seq_idle(self):
        self.ptr_sequencer = 'SEQ_IDLE'

    def seq_loop(self):
        self.test_loop.main()
        self.ptr_sequencer = 'SEQ_LOOP'
            
    def sequencer(self, argument) :
        self.ptr_sequencer = argument
        while self.running:
            func = self.steps_sequencer.get(self.ptr_sequencer, "nothing")
            func(self)
        
    steps_sequencer = {
        'SEQ_INIT' : seq_init,
        'SEQ_CONFIGURE_CONNECTION' : seq_configure_connection,
        'SEQ_CONNECT' : seq_connect,
        'SEQ_CONFIGURE_PRODUCT' : seq_configure_product,
        'SEQ_IDLE' : seq_idle,
        'SEQ_LOOP' : seq_loop
        }
        
    
if __name__ == "__main__":
    ConsoleTT1PV2()
