#!/usr/bin/python3

from utils import load_config, save_config
from serial_ports import serial_ports
import serial
from bcolors import bcolors

ERR_LORA_AT_SERIAL_ALIVE_PRODUCT = 1
ERR_LORA_AT_SERIAL_OK = 0
ERR_LORA_AT_SERIAL_NO_FRAME = -1

CONFIG_FILENAME = './config_lora_at.yml'

class LoRa_AT_Serial(object):

    def __init__(self) :
        self.config = load_config(CONFIG_FILENAME)
        self.port = self.config['comport']
        self.debit = self.config['baudrate']
        self.debug = False
        if (self.config['debug']):
            self.debug = True
            
    def save_configuration(self) :
        self.config['debug'] = False
        if (self.debug) :
            self.config['debug'] = True
        save_config(self.config, CONFIG_FILENAME)
        print(bcolors.WARNING+"Configuration saved"+bcolors.INFO)
            
    def configure(self):
        print(bcolors.WARNING + ".........................................")
        print("Serial port configuration")
        print("........................................." + bcolors.ENDC)
        print("List of serial ports ...")
        results = serial_ports()
        config = load_config(CONFIG_FILENAME)
        print("[-] : Do not change (" + config['comport'] + " selected) [Default]")
        for i in (range(1, len(results) + 1)) :
            print("[" + str(i) + '] : ' + results[i - 1])
        try:
            selected = input(bcolors.ACTION+"Type the Uart port to use and press <Enter> : "+bcolors.ENDC)
        except ValueError:
            pass
        if (selected != "0") and (selected != ""):
            self.port = results[int(selected) - 1]
            self.config['comport'] = self.port
            self.save_configuration()
            
    def send_frame(self, str, timeout=1, destination="DESTINATION_UART_BRIDGE", display_received_data = False):
        str_serial = []
        self.serialPort = serial.Serial(self.port, self.debit, timeout=timeout)

        datas = str.split()
        
        self.serialPort.write((str + '\n').encode('utf-8'))
        
        if (self.debug) :
            print(">> Send : " + str)

        err = self.receive_frame()
        if (err['str'] != "") :
            if (self.debug) :
                print("<< Receive : " + err['str'])
            elif (display_received_data) :
                print(err['str'])
        self.serialPort.close()
        return err
        
    def receive_frame(self) :
        ret = dict([('err', ERR_LORA_AT_SERIAL_NO_FRAME), ('str', "")])
        line = self.serialPort.read(256)

        if (line == b'') :
            ret['err'] = ERR_LORA_AT_SERIAL_NO_FRAME
            return ret
        for i in range(0,len(line)) :
            ret['str'] += chr(line[i])
        ret['err'] = ERR_LORA_AT_SERIAL_OK
        return ret
    
    def connect(self) :
        return 
    
    def wait_for_receive_lora_packet(self) :
        self.serialPort = serial.Serial(self.port, self.debit, timeout=1)
        result = "NO"
        while True :
            err = self.receive_frame()
            if err['err'] == ERR_LORA_AT_SERIAL_OK : 
                if (self.debug) :
                    print("<< Receive : " + err['str'])
                if (err['str'].find("RssiValue") != -1) : 
                    result = "YES"
                break
        self.serialPort.close()
        return(result)
    
    def execute(self, action="") :
        cmd = action.split()
        if (cmd[0] == "lora_receive_packet") :
            number_frames = self.wait_for_receive_lora_packet()
            print(bcolors.INFO+"LoRa packet received : " + number_frames+bcolors.ENDC)
        
        return True
