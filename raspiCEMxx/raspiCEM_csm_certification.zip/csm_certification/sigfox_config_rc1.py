#!/usr/bin/python3

from serial_ports import serial_ports
import serial

port = "/dev/ttyUSB0"
#port = "COM15"
debit = 115200

serialPort = serial.Serial(port, debit, timeout=1)
frame = [0xF2, 0x08, 0x02, 0x43, 0x53, 0x4D, 0x24, 0x0C, 0x00, 0x01]
for d in frame : 
    serialPort.write(d.to_bytes(1, byteorder='big'))
serialPort.close()
print("Product configured RC1")