#!/usr/bin/python3

from utils import load_config, save_config
from serial_ports import serial_ports
import serial
from bcolors import bcolors

CONFIG_FILENAME = './config.yml'

TT1PV2_FRAME_TYPE_STM32 = 1
TT1PV2_FRAME_TYPE_NRG2 = 0

TT1PV2_CONNECTION_TYPE_UART = 0
TT1PV2_CONNECTION_TYPE_BLE = 1

ERR_TT1PV2_SERIAL_ALIVE_PRODUCT = 1
ERR_TT1PV2_SERIAL_OK = 0
ERR_TT1PV2_SERIAL_NO_FRAME = -1

_DESTINATION_UART_RADIO = 0xF2
_DESTINATION_UART_BRIDGE = 0xF4


class TT1PV2_Serial(object):

    def __init__(self) :
        self.config = load_config(CONFIG_FILENAME)
        self.port = self.config['comport']
        self.debit = self.config['baudrate']
        self.uart_frame_type = TT1PV2_FRAME_TYPE_NRG2
        self.connection_type = TT1PV2_CONNECTION_TYPE_UART
        if (self.config['TT1PV2_connection_type'] == "TT1PV2_CONNECTION_TYPE_UART") :
            self.connection_type = TT1PV2_CONNECTION_TYPE_UART
        if (self.config['TT1PV2_connection_type'] == "TT1PV2_CONNECTION_TYPE_BLE") :
            self.connection_type = TT1PV2_CONNECTION_TYPE_BLE
        if (self.config['TT1PV2_frame_type'] == "TT1PV2_FRAME_TYPE_STM32") :
            self.uart_frame_type = TT1PV2_FRAME_TYPE_STM32
        self.debug = False
        if (self.config['debug']):
            self.debug = True
        self.destination = []
        self.destination.append("DESTINATION_UART_RADIO")    
        self.destination.append("DESTINATION_UART_BRIDGE")    

    def save_configuration(self) :
        self.config['debug'] = False
        if (self.debug) :
            self.config['debug'] = True
        save_config(self.config, CONFIG_FILENAME)
        print(bcolors.WARNING+"Configuration saved"+bcolors.INFO)
            
    def configure(self):
        print(bcolors.WARNING)
        print(".........................................")
        print("Connection type configuration")
        print(".........................................")
        print(bcolors.ENDC)
        if (self.connection_type == TT1PV2_CONNECTION_TYPE_UART) :
            print("[-] : Do not change (wired UART connection selected) [Default]")
        else:
            print("[-] : Do not change (BLE gateway connection selected) [Default]")
        print("[1] : Wired UART connection")
        print("[2] : BLE gateway connection")
        try:
            selected = input(bcolors.ACTION+"Type the connection type to use and press <Enter> : "+bcolors.ENDC)
        except ValueError:
            pass
        if (selected != "0") and (selected != ""):
            self.connection_type = int(selected) - 1
            if (self.connection_type == TT1PV2_CONNECTION_TYPE_UART) :
                self.config['TT1PV2_connection_type'] = "TT1PV2_CONNECTION_TYPE_UART"
            if (self.connection_type == TT1PV2_CONNECTION_TYPE_BLE) :
                self.config['TT1PV2_connection_type'] = "TT1PV2_CONNECTION_TYPE_BLE"
            self.save_configuration()

        print(bcolors.WARNING)
        print(".........................................")
        print("Serial port configuration")
        print(".........................................")
        print(bcolors.ENDC)
        if (self.connection_type == TT1PV2_CONNECTION_TYPE_UART) :
            print("List of serial ports (Wired UART connection) ...")
        if (self.connection_type == TT1PV2_CONNECTION_TYPE_BLE) :
            print("List of serial ports (BLE gateway connection) ...")
        results = serial_ports()
        config = load_config(CONFIG_FILENAME)
        print("[-] : Do not change (" + config['comport'] + " selected) [Default]")
        for i in (range(1, len(results) + 1)) :
            print("[" + str(i) + '] : ' + results[i - 1])
        try:
            selected = input(bcolors.ACTION+"Type the Uart port to use and press <Enter> : "+bcolors.ENDC)
        except ValueError:
            pass
        if (selected != "0") and (selected != ""):
            self.port = results[int(selected) - 1]
            self.config['comport'] = self.port
            save_config(self.config, CONFIG_FILENAME)
            print("Configuration saved")
            
                
            
    def send_frame(self, str, timeout=0.5, destination="DESTINATION_UART_RADIO", display_received_data = False):
        if (destination == "DESTINATION_UART_RADIO") :
            d = _DESTINATION_UART_RADIO
        if (destination == "DESTINATION_UART_BRIDGE") :
            d = _DESTINATION_UART_BRIDGE
        str_serial = []
        self.serialPort = serial.Serial(self.port, self.debit, timeout=timeout)

        if (self.uart_frame_type == TT1PV2_FRAME_TYPE_STM32):
            self.serialPort.write(d.to_bytes(1, byteorder='big'))
            self.serialPort.write((len(str) + 2).to_bytes(1, byteorder='big'))
            self.serialPort.write(b'\x64')
        self.serialPort.write((str + '\n').encode('utf-8'))
        
        if (self.debug) :
            print(">> Send : " + str)

        err = self.receive_frame()
        if (err['str'] != "") :
            if (self.debug) :
                print("<< Receive : " + err['str'])
            elif (display_received_data) :
                print(err['str'])
        self.serialPort.close()
        return err
        
    def receive_frame(self) :
        ret = dict([('err', ERR_TT1PV2_SERIAL_NO_FRAME), ('str', "")])
        line = self.serialPort.read(256)

        if (line == b'') :
            ret['err'] = ERR_TT1PV2_SERIAL_NO_FRAME
            return ret
        while (line[0] == 0) :
            line = line[1:]
            if (line == b'') :
                ret['err'] = ERR_TT1PV2_SERIAL_NO_FRAME
                return ret
        if (self.uart_frame_type == TT1PV2_FRAME_TYPE_STM32) :
            change_len_line = True
            while (len(line) > 0) and (change_len_line) :
                change_len_line = False     # Indicateur que la ligne a ete trounquee
                if (len(line) < 3) :
                    line = line + self.serialPort.read(256)
                    change_len_line = True
                elif (len(line) < line[1] + 2) :
                    line = line + self.serialPort.read(256)
                    change_len_line = True
                if (line[0] == int.from_bytes(b'\xF3', byteorder='big'))  :
                    if (line[2] == int.from_bytes(b'\x64', byteorder='big')) :
                        for i in range(line[1] - 1) :
                            ret['str'] = ret['str'] + chr(line[i + 3])
                        line = line[line[1] + 2:]
                        change_len_line = True
                        ret['err'] = ERR_TT1PV2_SERIAL_OK
                elif (line[0] == int.from_bytes(b'\xF5', byteorder='big'))  :
                    if (line[2] == int.from_bytes(b'\x64', byteorder='big')) :
                        for i in range(line[1] - 1) :
                            ret['str'] = ret['str'] + chr(line[i + 3])
                        line = line[line[1] + 2:]
                        change_len_line = True
                        ret['err'] = ERR_TT1PV2_SERIAL_OK
                elif (line[0] == int.from_bytes(b'\xFE', byteorder='big')) : 
                    if (line[2] == ord('R') or line[2] == ord('A')) : 
                        if (line[3] == ord(':'))  :
                            for i in range(line[1] - 2) :
                                ret['str'] = ret['str'] + chr(line[i + 4])
                            ret['str'] = ret['str'] + '\r' 
                            ret['err'] = ERR_TT1PV2_SERIAL_OK
                            line = line[line[1] + 2:]
                            change_len_line = True
                elif line[0] == int.from_bytes(b'\xF1', 'big') and (len(line) > 2):
                    if (line[1] == int.from_bytes(b'\x01', byteorder='big')) and (line[2] == int.from_bytes(b'\x05', byteorder='big')) :
                        line = line[line[1] + 2:]
                        change_len_line = True
                else :
                    line = ""
        return(ret)
    
    def receive_alive_frame(self) :
        line = self.serialPort.read(3)
        if (line == b'') :
            return ERR_TT1PV2_SERIAL_NO_FRAME

# Purge si le 1er octet est a 0
        while (line[0] == 0) :
            line = line[1:]
            if (line == b'') :
                return ERR_TT1PV2_SERIAL_NO_FRAME
        if (len(line) >= 3) :
            if line[0] == int.from_bytes(b'\xF1', 'big') and (len(line) > 2):
                if (line[1] == int.from_bytes(b'\x01', byteorder='big')) and (line[2] == int.from_bytes(b'\x05', byteorder='big')) :
                    line = line[line[1] + 2:]
                    return ERR_TT1PV2_SERIAL_ALIVE_PRODUCT
        return ERR_TT1PV2_SERIAL_NO_FRAME
        
    def connect(self) :
        self.m_compteurTickFrames = 0
        
        if (self.connection_type == TT1PV2_CONNECTION_TYPE_UART) :
            print("Waiting for tick frame detection ...")
            self.serialPort = serial.Serial(self.port, self.debit, timeout=0.5)
            while True :    
                err = self.receive_alive_frame()
                if (err == ERR_TT1PV2_SERIAL_ALIVE_PRODUCT) :
                    self.m_compteurTickFrames += 1
                    print("Tick frame detected ..." + str(self.m_compteurTickFrames))
                    if (self.m_compteurTickFrames > 4) :
                        print("Connected")
                        break
            self.serialPort.close()
        if (self.connection_type == TT1PV2_CONNECTION_TYPE_BLE) :
            print("Waiting for BLE connection ...")
            self.serialPort = serial.Serial(self.port, self.debit, timeout=0.5)
            while True :
                err = self.receive_frame()
                if (err['err'] == ERR_TT1PV2_SERIAL_OK) :
                    print(err['str'])
                if (err['str'].find("BLE_CONECTED") != -1) :
                    print("Connected")
                    break
            self.serialPort.close()

    def wait_for_bridge_connection(self) :
        self.serialPort = serial.Serial(self.port, self.debit, timeout=0.5)
        while True :
            err = self.receive_frame()
            if (err['err'] == ERR_TT1PV2_SERIAL_OK) :
                print(err['str'])
            if (err['str'].find("Stack Initialized") != -1) :
                break
        self.serialPort.close()
        return True

    def compute_sigfox_calibration(self, frequency = 900000000) :
        err = self.send_frame("set_xtal_frequency_offset " + str(int((frequency-900000000)/18)),timeout = 1.0, display_received_data = self.debug)
        err = self.send_frame("node_init 0 ",timeout = 1.0, display_received_data = self.debug)
        err = self.send_frame("get_xtal_frequency ",timeout = 1.0, display_received_data = self.debug)
        if (err['err'] == ERR_TT1PV2_SERIAL_OK) :
            value_position_left = err['str'].find("xtal_freq=") + len("xtal_freq=")
            value_position_right = err['str'].find(",",value_position_left)
            value_str = err['str'][value_position_left:value_position_right]
            return value_str
        else :
            return("-1")
        
        return err['str']

    def wait_for_receive_sigfox_frame(self, timeout = 10) :
        compteur_timeout = timeout
        self.serialPort = serial.Serial(self.port, self.debit, timeout=1)
        err = self.receive_frame()
        if (self.debug) and (err['err'] == ERR_TT1PV2_SERIAL_OK) :
            print("<< Receive : " + err['str'])
        while ((err['str'].find("receive_test_frame") == -1) and (compteur_timeout > 0)) :
            err = self.receive_frame()
            compteur_timeout -= 1
            if (self.debug) and (err['err'] == ERR_TT1PV2_SERIAL_OK) :
                print("<< Receive : " + err['str'])
            elif self.debug and (compteur_timeout == 0) : 
                print("<< Internal problem")
        self.serialPort.close()
        
        if (compteur_timeout == 0) :
            return ("-1")
        value_position = err['str'].find("State : ") + len("State : ")
        str_number_frames = err['str'][value_position:]
        return str_number_frames
#        else :
#            return "-1"

    def wait_for_receive_ble_frame(self, timeout = 10) :
        if (self.debug) :
            err = self.send_frame("ble_test_end",timeout = 1.0, display_received_data = True)
        else:
            err = self.send_frame("ble_test_end",timeout = 1.0)
        if (err['err'] == ERR_TT1PV2_SERIAL_OK) :
            value_position_left = err['str'].find("RX_Number_Of_Packets : ") + len("RX_Number_Of_Packets : ")
            value_position_right = err['str'].find("BleStatus",value_position_left)
            value_str = err['str'][value_position_left:value_position_right]
            return value_str
        else :
            return("-1")
            
    def wait_for_receive_frame(self, s="") :
        self.serialPort = serial.Serial(self.port, self.debit, timeout=1)
        err = self.receive_frame()
        if (self.debug) and (err['err'] == ERR_TT1PV2_SERIAL_OK) :
            print("<< Receive : " + err['str'])
        while (err['str'].find(s) == -1) :
            err = self.receive_frame()
            if (self.debug) and (err['err'] == ERR_TT1PV2_SERIAL_OK) :
                print("<< Receive : " + err['str'])
        self.serialPort.close()
        err['err'] = True
        return err

    def wait_for_transmit_lora_frame(self) :
        self.serialPort = serial.Serial(self.port, self.debit, timeout=1)
        while True :
            err = self.receive_frame()
            print("<< Receive : " + err['str'])
            if (err['str'][:12] == "LoRa Tx Done") :
                break
        self.serialPort.close()

    def wait_for_receive_lora_frame(self) :
        self.serialPort = serial.Serial(self.port, self.debit, timeout=1)
        result = "NO"
        while True :
            err = self.receive_frame()
            if err['err'] == ERR_TT1PV2_SERIAL_OK : 
                if (self.debug) :
                    print("<< Receive : " + err['str'])
                if (err['str'].find("LoRa Rx Done") != -1) : 
                    result = "YES"
                break
        self.serialPort.close()
        return(result)


    def execute(self, action="") :
        cmd = action.split()
        if (cmd[0] == "sigfox_compute_calibration") :
            err = self.compute_sigfox_calibration(frequency = int(cmd[1]))
            print("Calibration done (XTal frequency : "+ err + "Hz)")
        if (cmd[0] == "sigfox_receive_frame") :
            number_frames = self.wait_for_receive_sigfox_frame(timeout = 2*int(cmd[1]))
            print("Sigfox frames received : " + number_frames)
        if (cmd[0] == "ble_receive_frame") :
            number_frames = self.wait_for_receive_ble_frame()
            print(bcolors.INFO+"BLE frames received : " + number_frames+bcolors.ENDC)
        if (cmd[0] == "lora_receive_frame") :
            number_frames = self.wait_for_receive_lora_frame()
            print(bcolors.INFO+"LoRa frames received : " + number_frames+bcolors.ENDC)
    
