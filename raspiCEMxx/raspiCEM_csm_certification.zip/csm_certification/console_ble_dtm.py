#!/usr/bin/python3
# -*- coding: utf8 -*-

import time
from ble_dtm_serial import BLE_DTM_Serial
import json
from test_loop import test_loop
from bcolors import bcolors

SOFTWARE_VERSION = '1.0.0'

JSON_FILENAME = "./ble_dtm_tests.json"

DEBUG = 0

class ConsoleBLEDTM(object):

    def __init__(self) :
        
        self.ble_dtm_serial = BLE_DTM_Serial()
        self.ptr_sequencer = 'SEQ_INIT'
        self.running = True
        self.test_loop = test_loop(interface=self.ble_dtm_serial,json_filename=JSON_FILENAME)
        self.sequencer(self.ptr_sequencer)
            
    def seq_init(self):
        print(bcolors.HEADER)
        print("=========================================")
        print("         console BLE DTM")
        print("                                  v" + SOFTWARE_VERSION)
        print("=========================================")
        print(bcolors.ENDC)
        if (DEBUG == 1) :
            self.ptr_sequencer = 'SEQ_LOOP'
        else :
            self.ptr_sequencer = 'SEQ_CONFIGURE_CONNECTION'

    def seq_configure_connection(self):
        self.ble_dtm_serial.configure()
        self.ptr_sequencer = 'SEQ_CONNECT'
        
    def seq_connect(self):
        self.ble_dtm_serial.connect()
        self.ptr_sequencer = 'SEQ_CONFIGURE_PRODUCT'

    def seq_configure_product(self):
        self.ptr_sequencer = 'SEQ_LOOP'
            
    def seq_idle(self):
        self.ptr_sequencer = 'SEQ_IDLE'

    def seq_loop(self):
        self.test_loop.main()
        self.ptr_sequencer = 'SEQ_LOOP'
            
    def sequencer(self, argument) :
        self.ptr_sequencer = argument
        while self.running:
            func = self.steps_sequencer.get(self.ptr_sequencer, "nothing")
            func(self)
        
    steps_sequencer = {
        'SEQ_INIT' : seq_init,
        'SEQ_CONFIGURE_CONNECTION' : seq_configure_connection,
        'SEQ_CONNECT' : seq_connect,
        'SEQ_CONFIGURE_PRODUCT' : seq_configure_product,
        'SEQ_IDLE' : seq_idle,
        'SEQ_LOOP' : seq_loop
        }
        
    
if __name__ == "__main__":
    ConsoleBLEDTM()
